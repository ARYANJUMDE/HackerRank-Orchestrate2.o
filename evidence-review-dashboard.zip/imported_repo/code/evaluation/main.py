#!/usr/bin/env python3
"""
Multi-Modal Evidence Review - Evaluation Suite
Loads 'sample_claims.csv' as a labeled ground truth dataset, executes the VLM prediction logic,
and computes evaluation metrics (Accuracy, Matches, Error Rates) across all target fields.
"""

import os
import csv
import sys
import time
from typing import List, Dict, Any
from pydantic import BaseModel, Field

try:
    from google import genai
    from google.genai import types
except ImportError:
    print("\x1b[33mWarning: 'google-genai' package is not installed.\x1b[0m")
    sys.exit(1)

from PIL import Image

class ClaimVerificationResult(BaseModel):
    evidence_standard_met: bool = Field(description="true/false")
    evidence_standard_met_reason: str = Field(description="Description")
    risk_flags: str = Field(description="Flags")
    issue_type: str = Field(description="Issue")
    object_part: str = Field(description="Component")
    claim_status: str = Field(description="Status")
    claim_status_justification: str = Field(description="Justification")
    supporting_image_ids: str = Field(description="Image IDs")
    valid_image: bool = Field(description="validity")
    severity: str = Field(description="Severity")


def load_csv(file_path: str) -> List[Dict[str, str]]:
    if not os.path.exists(file_path):
        return []
    with open(file_path, mode='r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        return list(reader)


def run_evaluation():
    # Setup directories
    eval_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_dir = os.path.abspath(os.path.join(eval_dir, '..', '..', 'dataset'))
    
    path_sample = os.path.join(dataset_dir, 'sample_claims.csv')
    path_user_history = os.path.join(dataset_dir, 'user_history.csv')
    path_evidence_req = os.path.join(dataset_dir, 'evidence_requirements.csv')

    print(f"Loading Ground Truth Labeled Dataset: {path_sample}")
    samples = load_csv(path_sample)
    user_history = load_csv(path_user_history)
    evidence_reqs = load_csv(path_evidence_req)

    if not samples:
        print(f"Error: Could not load '{path_sample}'.")
        sys.exit(1)

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("\x1b[31mError: GEMINI_API_KEY environment variable is missing for running evaluation.\x1b[0m")
        sys.exit(1)

    client = genai.Client(api_key=api_key)
    user_map = {u['user_id']: u for u in user_history}

    total_runs = len(samples)
    matches_status = 0
    matches_issue = 0
    matches_part = 0
    matches_severity = 0

    print(f"\nStarting evaluation of {total_runs} benchmark rows on Gemini model suite...")

    for idx, row in enumerate(samples[:10]):  # Limit to first 10 for evaluation script validation
        user_id = row.get('user_id', '')
        claim_object = row.get('claim_object', '')
        user_claim = row.get('user_claim', '')
        image_paths_str = row.get('image_paths', '')
        
        # Ground truths
        gt_status = row.get('claim_status', '').strip().lower()
        gt_issue = row.get('issue_type', '').strip().lower()
        gt_part = row.get('object_part', '').strip().lower()
        gt_severity = row.get('severity', '').strip().lower()

        print(f"\n[{idx+1}/{min(10, total_runs)}] Auditing Case: {user_id} - Ground Truth: status={gt_status}, part={gt_part}")

        matched_reqs = [er for er in evidence_reqs if er['claim_object'] == claim_object or er['claim_object'] == 'all']
        req_text = "\n".join([f"- [{req['requirement_id']}] Applies to: {req['applies_to']} -> Minimum: {req['minimum_image_evidence']}" for req in matched_reqs])

        history_record = user_map.get(user_id)
        if history_record:
            history_text = f"Past claims: {history_record['past_claim_count']}, accept: {history_record['accept_claim']}, reject: {history_record['rejected_claim']}, history flags: {history_record['history_flags']}"
        else:
            history_text = "No prior history record."

        contents_payload = []
        # Support sample image directory prefixing
        relative_paths = image_paths_str.split(';')
        for img_rel in relative_paths:
            full_img_p = os.path.join(dataset_dir, img_rel)
            if os.path.exists(full_img_p):
                try:
                    img = Image.open(full_img_p)
                    contents_payload.append(img)
                except Exception as e:
                    print(f"  - Warning: Failed upload '{img_rel}' ({e})")

        prompt = f"""You are an automated physical damage claims verifier.
Analyze the provided information and image(s) to determine whether the submitted images support the user's claims.

*** Claims Context ***
Claim Object: {claim_object}
Transcript: {user_claim}

*** Rules & Evidence Standards Requirements ***
{req_text}

*** User Background History ***
{history_text}

*** INSTRUCTIONS ***
Predict standard attributes strictly modeled after the ClaimVerificationResult schema.
Ensure exact field alignments on status, issue_type, object_part, severity.
"""

        contents_payload.append(prompt)

        prediction = None
        # Try Flash first
        for model in ['gemini-3.1-flash-lite', 'gemini-2.5-flash']:
            try:
                response = client.models.generate_content(
                    model=model,
                    contents=contents_payload,
                    config=types.GenerateContentConfig(
                        response_mime_type="application/json",
                        response_schema=ClaimVerificationResult,
                    )
                )
                prediction = response.parsed
                break
            except Exception as e:
                continue

        if prediction:
            pred_status = prediction.claim_status.strip().lower()
            pred_issue = prediction.issue_type.strip().lower()
            pred_part = prediction.object_part.strip().lower()
            pred_severity = prediction.severity.strip().lower()

            status_ok = pred_status == gt_status
            issue_ok = pred_issue == gt_issue
            part_ok = pred_part == gt_part
            sev_ok = pred_severity == gt_severity

            if status_ok: matches_status += 1
            if issue_ok: matches_issue += 1
            if part_ok: matches_part += 1
            if sev_ok: matches_severity += 1

            print(f"  Prediction -> Status: {pred_status} ({'MATCH' if status_ok else 'MISMATCH'})")
            print(f"             -> Issue:  {pred_issue} ({'MATCH' if issue_ok else 'MISMATCH'})")
            print(f"             -> Part:   {pred_part} ({'MATCH' if part_ok else 'MISMATCH'})")
        else:
            print("  Warning: Model returned no viable structured criteria.")

    tested_total = min(10, total_runs)
    print("\n" + "="*40 + "\n       BENCHMARK METRICS EVALUATION REPORT\n" + "="*40)
    print(f"Total Evaluated Benchmark Rows: {tested_total}")
    print(f"Claim Status accuracy:         {(matches_status / tested_total) * 100:.2f}% ({matches_status}/{tested_total})")
    print(f"Issue Type accuracy:           {(matches_issue / tested_total) * 100:.2f}% ({matches_issue}/{tested_total})")
    print(f"Object Part accuracy:          {(matches_part / tested_total) * 100:.2f}% ({matches_part}/{tested_total})")
    print(f"Severity accuracy:             {(matches_severity / tested_total) * 100:.2f}% ({matches_severity}/{tested_total})")
    print("="*40)


if __name__ == '__main__':
    run_evaluation()
