import fs from 'fs';
import path from 'path';

const FILES_TO_DOWNLOAD = [
  'README.md',
  'AGENTS.md',
  'CLAUDE.md',
  'problem_statement.md',
  'code/main.py',
  'dataset/claims.csv',
  'dataset/evidence_requirements.csv',
  'dataset/sample_claims.csv',
  'dataset/user_history.csv',
  'dataset/output.csv'
];

const BASE_RAW_URL = 'https://raw.githubusercontent.com/interviewstreet/hackerrank-orchestrate-june26/main';

async function fetchRaw(url: string): Promise<Buffer> {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch raw ${url}: ${res.status} ${res.statusText}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function main() {
  const targetDir = path.join(process.cwd(), 'imported_repo');
  for (const relPath of FILES_TO_DOWNLOAD) {
    const localPath = path.join(targetDir, relPath);
    const parentDir = path.dirname(localPath);
    fs.mkdirSync(parentDir, { recursive: true });
    
    if (fs.existsSync(localPath)) {
      console.log(`Skipping existing file: ${relPath}`);
      continue;
    }
    
    const rawUrl = `${BASE_RAW_URL}/${relPath}`;
    console.log(`Downloading raw file: ${rawUrl} -> ${localPath}`);
    try {
      const buffer = await fetchRaw(rawUrl);
      fs.writeFileSync(localPath, buffer);
    } catch (err) {
      console.error(`Failed to download ${relPath}:`, err);
    }
  }
  console.log('Download complete!');
}

main();
