export interface ClaimInput {
  user_id: string;
  image_paths: string;
  user_claim: string;
  claim_object: 'car' | 'laptop' | 'package';
}

export interface ClaimOutput {
  user_id: string;
  image_paths: string;
  user_claim: string;
  claim_object: 'car' | 'laptop' | 'package';
  evidence_standard_met: boolean;
  evidence_standard_met_reason: string;
  risk_flags: string;
  issue_type: string;
  object_part: string;
  claim_status: string;
  claim_status_justification: string;
  supporting_image_ids: string;
  valid_image: boolean;
  severity: string;
}

export interface UserHistory {
  user_id: string;
  past_claim_count: number;
  accept_claim: number;
  manual_review_claim: number;
  rejected_claim: number;
  last_90_days_claim_count: number;
  history_flags: string;
  history_summary: string;
}

export interface EvidenceRequirement {
  requirement_id: string;
  claim_object: string;
  applies_to: string;
  minimum_image_evidence: string;
}

export interface OperationalMetrics {
  totalCalls: number;
  totalInputTokens: number;
  totalOutputTokens: number;
  totalImagesProcessed: number;
  estimatedCost: number;
  averageLatencyMs: number;
}
