import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  User, 
  ShieldCheck, 
  AlertTriangle, 
  ShieldAlert, 
  Clock, 
  FolderOpen,
  ArrowRight,
  ClipboardList
} from 'lucide-react';
import { UserHistory, EvidenceRequirement } from '../types';

interface KnowledgeBaseProps {
  userHistory: UserHistory[];
  evidenceRequirements: EvidenceRequirement[];
}

export default function KnowledgeBase({ userHistory, evidenceRequirements }: KnowledgeBaseProps) {
  const [activeSubTab, setActiveSubTab] = useState<'standards' | 'users'>('standards');
  const [userQuery, setUserQuery] = useState<string>('');
  const [selectedUser, setSelectedUser] = useState<UserHistory | null>(null);

  // Filter evidence requirements
  const [standardsObjFilter, setStandardsObjFilter] = useState<string>('all-active');
  const filteredRequirements = evidenceRequirements.filter(req => {
    if (standardsObjFilter === 'all-active') return true;
    return req.claim_object.toLowerCase() === standardsObjFilter.toLowerCase() || req.claim_object === 'all';
  });

  const handleUserSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = userQuery.trim().toLowerCase();
    const match = userHistory.find(u => u.user_id.toLowerCase() === query);
    if (match) {
      setSelectedUser(match);
    } else {
      alert(`User ID "${userQuery}" not found. Try typical IDs like: user_005, user_008, user_013.`);
    }
  };

  const handleSelectPreUser = (user: UserHistory) => {
    setSelectedUser(user);
    setUserQuery(user.user_id);
  };

  return (
    <div className="flex flex-col gap-6" id="knowledge-base">
      
      {/* Knowledge navigation tabs */}
      <div className="flex bg-slate-900 border border-slate-800 p-2.5 rounded-xl font-sans text-xs flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-850/80">
          <button
            onClick={() => setActiveSubTab('standards')}
            className={`px-4 py-2 rounded-md font-medium transition flex items-center gap-1.5 ${
              activeSubTab === 'standards' ? 'bg-slate-800 text-teal-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Minimum Evidence Standards Checklist
          </button>
          <button
            onClick={() => setActiveSubTab('users')}
            className={`px-4 py-2 rounded-md font-medium transition flex items-center gap-1.5 ${
              activeSubTab === 'users' ? 'bg-slate-800 text-teal-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            User Trust Profile database
          </button>
        </div>

        <span className="text-[10px] font-mono text-indigo-400">Claims Compliance Documentation</span>
      </div>

      {activeSubTab === 'standards' ? (
        /* SUB-TAB A: EVIDENCE REQUIREMENTS STANDARDS */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch font-sans">
          
          {/* Object category picker Sidebar */}
          <div className="md:col-span-3 bg-slate-900 border border-slate-800 p-4.5 rounded-xl flex flex-col gap-3">
            <h3 className="text-xs text-slate-400 font-mono uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <ClipboardList className="w-4 h-4 text-teal-500" /> Objects Filter
            </h3>

            {[
              { id: 'all-active', label: 'All Requirements' },
              { id: 'car', label: 'Automotive (car)' },
              { id: 'laptop', label: 'Electronics (laptop)' },
              { id: 'package', label: 'Logistics (package)' }
            ].map(tab => {
              const isActive = standardsObjFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setStandardsObjFilter(tab.id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs transition border font-medium ${
                    isActive 
                      ? 'bg-slate-805 text-teal-400 border-teal-500/20 shadow-md'
                      : 'border-transparent text-slate-400 hover:bg-slate-800/10'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Checklist content listings */}
          <div className="md:col-span-9 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col gap-4">
            <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-slate-200">Required Photographic Checklists</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Rules evaluating the physical object and damage parts usability</p>
              </div>
              <span className="text-[10px] bg-slate-950 border border-slate-850 px-2.5 py-0.5 rounded font-mono text-slate-400">
                {filteredRequirements.length} rules active
              </span>
            </div>

            <div className="flex flex-col gap-4 max-h-[480px] overflow-y-auto pr-1">
              {filteredRequirements.map((req, rIdx) => {
                return (
                  <div key={rIdx} className="bg-slate-950/30 border border-slate-850/60 p-4 rounded-xl hover:border-slate-800 transition flex flex-col gap-2">
                    <div className="flex justify-between items-start gap-2 flex-wrap sm:flex-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] text-teal-400 font-bold bg-slate-950 border border-slate-800 px-2 py-0.5 rounded">
                          {req.requirement_id}
                        </span>
                        <h4 className="font-semibold text-slate-200 text-xs capitalize">{req.applies_to}</h4>
                      </div>
                      <span className="text-[10px] font-mono uppercase bg-slate-900 border border-slate-800 rounded px-2.5 py-0.5 text-slate-500">
                        Object: {req.claim_object}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 pl-1 leading-relaxed border-l-2 border-indigo-500/30 font-serif italic mt-1 bg-slate-950/20 p-2.5 rounded-r">
                      &ldquo;{req.minimum_image_evidence}&rdquo;
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      ) : (
        /* SUB-TAB B: USER RISK HISTORY LOOKUPS */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch font-sans" id="trust-profiles">
          
          {/* Lookup Panel Left */}
          <div className="md:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col gap-4">
            <div>
              <h3 className="font-semibold text-slate-200">Customer Records Query</h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-normal">
                Search the historical logs to scrutinize users of concern, check past exaggeration stats, and look up associated risk flags.
              </p>
            </div>

            <form onSubmit={handleUserSearch} className="flex gap-2 bg-slate-950 border border-slate-850 rounded-lg p-1">
              <div className="flex items-center gap-2 pl-2.5 flex-1 text-slate-500">
                <Search className="w-4 h-4 flex-shrink-0" />
                <input
                  type="text"
                  placeholder="Query user_id (e.g. user_005)..."
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                  className="w-full bg-transparent border-none text-xs text-slate-300 placeholder-slate-600 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 text-indigo-400 px-3 py-1.5 rounded-md text-[11px] font-semibold transition"
              >
                Lookup
              </button>
            </form>

            <div className="border-t border-slate-800/60 pt-4">
              <span className="text-[10px] font-mono text-slate-500 block uppercase tracking-wider mb-2.5">High-Risk Users of Concern</span>
              <div className="flex flex-col gap-1.5 max-h-[180px] overflow-y-auto">
                {userHistory
                  .filter(u => u.history_flags !== 'none')
                  .map((user, idx) => {
                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectPreUser(user)}
                        className="w-full text-left p-2.5 bg-slate-950/40 rounded-lg text-xs leading-none transition border border-rose-500/10 hover:border-rose-500/20 hover:bg-slate-950 flex justify-between items-center"
                      >
                        <span className="font-mono text-rose-400 font-bold">{user.user_id}</span>
                        <span className="text-[9px] font-mono bg-rose-500/10 border border-rose-500/10 text-rose-400 px-1.5 py-0.5 rounded uppercase">
                          {user.history_flags.split(';')[0]}
                        </span>
                      </button>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* User records details panels Right */}
          <div className="md:col-span-7 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col">
            {selectedUser ? (
              <div className="flex flex-col gap-4 flex-1">
                <div className="border-b border-slate-800 pb-3.5 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm bg-slate-950 border border-slate-850 py-1 px-3 rounded text-teal-400 font-bold">
                      {selectedUser.user_id}
                    </span>
                    <span className="text-xs text-slate-500">Security Verification Clearance Record</span>
                  </div>

                  {selectedUser.history_flags !== 'none' ? (
                    <span className="text-[9px] font-bold uppercase tracking-wider border border-rose-500/30 text-rose-400 bg-rose-500/5 px-2.5 py-1 rounded">
                      RISK FLAGGED
                    </span>
                  ) : (
                    <span className="text-[9px] font-bold uppercase tracking-wider border border-emerald-500/30 text-emerald-400 bg-emerald-500/5 px-2.5 py-1 rounded">
                      TRUST APPROVED
                    </span>
                  )}
                </div>

                {/* Risk Overview card */}
                <div className={`p-4 rounded-xl border flex gap-3.5 items-center ${
                  selectedUser.history_flags !== 'none'
                    ? 'border-rose-500/20 bg-rose-500/5 text-rose-300'
                    : 'border-slate-800 bg-slate-950/40 text-slate-400'
                }`}>
                  {selectedUser.history_flags !== 'none' ? (
                    <ShieldAlert className="w-5 h-5 flex-shrink-0 text-rose-400" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 flex-shrink-0 text-emerald-400" />
                  )}
                  <div className="text-xs">
                    <p className="font-semibold text-slate-300">Historical Audit Report</p>
                    <p className="mt-0.5 leading-relaxed font-serif italic text-slate-400">&ldquo;{selectedUser.history_summary}&rdquo;</p>
                  </div>
                </div>

                {/* Grid of numbers */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
                  <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg text-center font-mono">
                    <span className="text-[9px] text-slate-500 uppercase block tracking-wider">Accepted claims</span>
                    <span className="text-xl font-bold text-slate-300 mt-1 block">{selectedUser.accept_claim}</span>
                  </div>
                  <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg text-center font-mono">
                    <span className="text-[9px] text-slate-500 uppercase block tracking-wider">Rejected claims</span>
                    <span className="text-xl font-bold text-rose-400 mt-1 block">{selectedUser.rejected_claim}</span>
                  </div>
                  <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg text-center font-mono">
                    <span className="text-[9px] text-slate-500 uppercase block tracking-wider">Manual reviews</span>
                    <span className="text-xl font-bold text-amber-400 mt-1 block">{selectedUser.manual_review_claim}</span>
                  </div>
                  <div className="bg-slate-950 border border-slate-850 p-3 rounded-lg text-center font-mono">
                    <span className="text-[10px] text-slate-500 uppercase block tracking-wider">90-Day Velocity</span>
                    <span className="text-xl font-bold text-slate-300 mt-1 block">{selectedUser.last_90_days_claim_count}</span>
                  </div>
                </div>

                <div className="border-t border-slate-800/60 pt-4.5 mt-auto flex flex-col gap-1.5 text-[11px] font-mono text-slate-500">
                  <div className="flex justify-between">
                    <span>SECURITY RISK FLAGS:</span>
                    <span className="text-slate-300 uppercase font-bold">{selectedUser.history_flags}</span>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span>LIFETIME FILINGS ATTEMPTED:</span>
                    <span className="text-slate-300 font-bold">{selectedUser.past_claim_count} records</span>
                  </div>
                </div>

              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-600 border border-dashed border-slate-850 rounded-xl">
                <User className="w-10 h-10 text-slate-700 mb-2" />
                <h4 className="font-semibold text-slate-400 text-xs">No trust profile loaded</h4>
                <p className="text-[10.5px] text-slate-500 max-w-xs mt-0.5 leading-relaxed">
                  Search or select a security user profile on the left panel lookups to detailed past attempts, validation risk statistics, and summaries.
                </p>
              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
}
