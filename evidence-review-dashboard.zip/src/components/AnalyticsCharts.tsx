import React, { useState } from 'react';
import { 
  TrendingUp, 
  BarChart2, 
  CheckCircle, 
  XOctagon, 
  RefreshCw, 
  CheckSquare, 
  ShieldCheck, 
  Info,
  ShieldAlert,
  Sliders
} from 'lucide-react';
import { ClaimOutput } from '../types';

interface AnalyticsChartsProps {
  sampleClaims: ClaimOutput[];
  outputClaims: ClaimOutput[];
}

export default function AnalyticsCharts({ sampleClaims, outputClaims }: AnalyticsChartsProps) {
  const [activeAccuracyTest, setActiveAccuracyTest] = useState<boolean>(false);
  const [testedIndices, setTestedIndices] = useState<Record<number, ClaimOutput>>({});
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [progressMsg, setProgressMsg] = useState<string>('');

  const currentDataset = outputClaims.length > 0 ? outputClaims : sampleClaims;

  // 1. Calculate status distributions
  const statusCounts = currentDataset.reduce((acc, row) => {
    const status = row.claim_status || 'unknown';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalStatus = Object.values(statusCounts).reduce((a, b) => a + b, 0) || 1;

  // 2. Group by Issue Family
  const issueCounts = currentDataset.reduce((acc, row) => {
    const issue = row.issue_type || 'unknown';
    acc[issue] = (acc[issue] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedIssues = Object.entries(issueCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  const maxIssueCount = Math.max(...sortedIssues.map(i => i[1]), 1);

  // 3. Group by Severity
  const severityCounts = currentDataset.reduce((acc, row) => {
    const s = row.severity || 'unknown';
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Run a full benchmark comparison of entire Sample dataset
  const runSelfAccuracyBenchmark = async () => {
    setIsTesting(true);
    setTestedIndices({});
    setProgressMsg('Initiating comparative analyzer benchmark...');

    const tested: Record<number, ClaimOutput> = {};
    for (let i = 0; i < sampleClaims.length; i++) {
      const row = sampleClaims[i];
      setProgressMsg(`Benchmarking row ${i + 1} of ${sampleClaims.length} (evaluating user ${row.user_id})...`);
      
      try {
        const response = await fetch('/api/evaluate_row', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ row_id: i, is_sample: true }),
        });
        if (response.ok) {
          const data = await response.json();
          tested[i] = data.prediction;
        }
      } catch (err) {
        console.error('Benchmark row error:', err);
      }
      // brief pause to throttle rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    setTestedIndices(tested);
    setIsTesting(false);
    setProgressMsg('Analysis complete!');
  };

  // Calculate self accuracy stats
  const runCount = Object.keys(testedIndices).length;
  let matchesCount = 0;
  let partMatchesCount = 0;
  let issueMatchesCount = 0;

  if (runCount > 0) {
    Object.entries(testedIndices).forEach(([idxStr, pred]) => {
      const idx = parseInt(idxStr);
      const groundTruth = sampleClaims[idx];
      const p = pred as ClaimOutput;
      if (groundTruth) {
        if (p.claim_status === groundTruth.claim_status) matchesCount++;
        if (p.object_part === groundTruth.object_part) partMatchesCount++;
        if (p.issue_type === groundTruth.issue_type) issueMatchesCount++;
      }
    });
  }

  const accuracyPct = runCount > 0 ? Math.round((matchesCount / runCount) * 100) : 0;
  const partAccuracyPct = runCount > 0 ? Math.round((partMatchesCount / runCount) * 100) : 0;
  const issueAccuracyPct = runCount > 0 ? Math.round((issueMatchesCount / runCount) * 100) : 0;

  return (
    <div className="flex flex-col gap-6" id="claims-diagnostics">
      
      {/* HEADER COMPARATOR PREFERENCES */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-sans">
        <div>
          <h2 className="font-medium text-slate-200">System Metrics & Classifiers</h2>
          <p className="text-[11px] text-slate-500 mt-1">
            Displaying analytical properties for {outputClaims.length > 0 ? 'Batch Output CSV Database (Test dataset)' : 'Sample Labeled Database'}.
          </p>
        </div>

        <button
          onClick={() => setActiveAccuracyTest(!activeAccuracyTest)}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 text-[11px] font-semibold border rounded-lg transition ${
            activeAccuracyTest 
              ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/35'
              : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          {activeAccuracyTest ? 'Show Analytical Charts' : 'Open Verification Benchmark'}
        </button>
      </div>

      {!activeAccuracyTest ? (
        /* SECTION A: SYSTEM CHARTS & PLOTS */
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch font-sans">
          
          {/* Pie Distribution chart */}
          <div className="md:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col">
            <h3 className="text-xs text-slate-400 font-mono uppercase tracking-wider mb-4 flex items-center gap-2">
              <BarChart2 className="w-3.5 h-3.5 text-teal-400" /> Case Verdict Breakdown (claim_status)
            </h3>

            <div className="flex-1 flex flex-col sm:flex-row items-center gap-6 justify-center min-h-[180px]">
              {/* Custom SVG Pie Chart */}
              <div className="relative w-36 h-36">
                <svg viewBox="0 0 36 36" className="w-full h-full transform -rotate-90">
                  {/* Background Circle */}
                  <circle cx="18" cy="18" r="15.915" fill="none" stroke="#0f172a" strokeWidth="4" />
                  
                  {/* slices */}
                  {(() => {
                    let accPercent = 0;
                    const slices = [
                      { val: statusCounts.supported || 0, color: '#10b981' },
                      { val: statusCounts.contradicted || 0, color: '#f43f5e' },
                      { val: statusCounts.not_enough_information || 0, color: '#f59e0b' }
                    ].filter(s => s.val > 0);

                    return slices.map((slice, sIdx) => {
                      const pct = (slice.val / totalStatus) * 100;
                      const strokeDasharray = `${pct} ${100 - pct}`;
                      const strokeDashoffset = 100 - accPercent + 25;
                      accPercent += pct;
                      return (
                        <circle
                          key={sIdx}
                          cx="18"
                          cy="18"
                          r="15.915"
                          fill="none"
                          stroke={slice.color}
                          strokeWidth="2.8"
                          strokeDasharray={strokeDasharray}
                          strokeDashoffset={strokeDashoffset}
                          className="transition-all duration-500 hover:stroke-[3.5] cursor-pointer"
                        />
                      );
                    });
                  })()}
                </svg>

                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-lg font-bold font-mono text-slate-200">{totalStatus}</span>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Row Cases</span>
                </div>
              </div>

              {/* Legend columns */}
              <div className="flex flex-col gap-2 flex-shrink-0 text-[11px] font-mono text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded bg-emerald-500 flex-shrink-0" />
                  <span className="w-24">Supported:</span>
                  <span className="font-bold text-slate-200">{statusCounts.supported || 0}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded bg-rose-500 flex-shrink-0" />
                  <span className="w-24">Contradicted:</span>
                  <span className="font-bold text-slate-200">{statusCounts.contradicted || 0}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded bg-amber-500 flex-shrink-0" />
                  <span className="w-24">Not Enough Info:</span>
                  <span className="font-bold text-slate-200">{statusCounts.not_enough_information || 0}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Issue Family Bar Chart */}
          <div className="md:col-span-7 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col">
            <h3 className="text-xs text-slate-400 font-mono uppercase tracking-wider mb-4 flex items-center gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-400" /> Primary Issue Families Distribution
            </h3>

            <div className="flex-1 flex flex-col gap-3 justify-center min-h-[180px]">
              {sortedIssues.map(([issueName, count], idx) => {
                const widthPct = Math.round((count / maxIssueCount) * 100);
                return (
                  <div key={idx} className="flex flex-col gap-1 text-[11px] font-mono">
                    <div className="flex justify-between text-slate-400">
                      <span className="capitalize">{issueName.replace(/_/g, ' ')}</span>
                      <span className="text-slate-300 font-bold">{count} ({Math.round(count / totalStatus * 100)}%)</span>
                    </div>
                    <div className="w-full bg-slate-950 border border-slate-850 h-2.5 rounded-sm overflow-hidden flex items-stretch">
                      <div 
                        className="bg-gradient-to-r from-indigo-500 to-teal-500 rounded-sm transition-all duration-500"
                        style={{ width: `${widthPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Severity bento cards */}
          <div className="md:col-span-12 bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col gap-4">
            <h3 className="text-xs text-slate-400 font-mono uppercase tracking-wider flex items-center gap-2">
              <CheckSquare className="w-3.5 h-3.5 text-teal-400" /> Claim Severity Distribution Metrics
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {[
                { name: 'High Severity', count: severityCounts.high || 0, color: 'border-red-500/20 text-red-400 bg-red-500/5' },
                { name: 'Medium Severity', count: severityCounts.medium || 0, color: 'border-orange-500/20 text-orange-400 bg-orange-500/5' },
                { name: 'Low Severity', count: severityCounts.low || 0, color: 'border-emerald-500/20 text-emerald-400 bg-emerald-500/5' },
                { name: 'No Damage', count: severityCounts.none || 0, color: 'border-slate-800 text-slate-400 bg-slate-950/20' },
                { name: 'Unknown', count: severityCounts.unknown || 0, color: 'border-slate-800 text-slate-500 bg-slate-950/20' }
              ].map((sev, sIdx) => {
                return (
                  <div key={sIdx} className={`border p-3.5 rounded-xl text-center flex flex-col gap-0.5 justify-center ${sev.color}`}>
                    <span className="text-[10px] uppercase tracking-wider font-mono opacity-60 font-semibold">{sev.name}</span>
                    <span className="text-2xl font-bold font-mono mt-1">{sev.count}</span>
                    <span className="text-[9px] font-mono opacity-40">cases flagged</span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      ) : (
        /* SECTION B: COMPENSATIVE AUDIT BENCHMARK TESTS */
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col gap-5 font-sans" id="diagnostics-accuracy-test">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
            <div className="text-xs">
              <h3 className="font-semibold text-slate-200">Verification Accuracy Audit (Ground-Truth Comparative Core)</h3>
              <p className="text-[11px] text-slate-500 mt-1 max-w-xl">
                Executes a live verification run across the entire reference <strong>Sample Dataset</strong> (20 cases) to comparison-profile Gemini predictions directly against expected human ground-truths.
              </p>
            </div>

            <button
              onClick={runSelfAccuracyBenchmark}
              disabled={isTesting}
              className={`flex items-center gap-2 px-4 py-2 font-bold text-xs rounded-lg transition-all ${
                isTesting 
                  ? 'bg-slate-800 text-slate-500 border border-slate-800/80 cursor-not-allowed'
                  : 'bg-indigo-500 hover:bg-indigo-400 text-white shadow-md shadow-indigo-500/5'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              {isTesting ? 'Benchmark Test Running...' : 'Execute Comparative Audit'}
            </button>
          </div>

          {progressMsg && (
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-850 text-xs font-mono text-teal-400 flex items-center gap-3">
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-teal-500"></span>
              </span>
              {progressMsg}
            </div>
          )}

          {runCount > 0 ? (
            <div className="flex flex-col gap-6">
              
              {/* ACCURACY CARDS METRICS */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-center flex flex-col gap-1">
                  <div className="flex justify-center text-indigo-400 mb-1">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">Decision status accuracy</span>
                  <span className="text-3xl font-bold font-mono text-teal-400 mt-1">
                    {accuracyPct}%
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-600">({matchesCount} of {runCount} matched)</span>
                </div>

                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-center flex flex-col gap-1">
                  <div className="flex justify-center text-teal-400 mb-1">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">Bumper/part localisation match</span>
                  <span className="text-3xl font-bold font-mono text-indigo-400 mt-1">
                    {partAccuracyPct}%
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-600">({partMatchesCount} of {runCount} matched)</span>
                </div>

                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-center flex flex-col gap-1">
                  <div className="flex justify-center text-amber-400 mb-1">
                    <Info className="w-5 h-5" />
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">Issue classification match</span>
                  <span className="text-3xl font-bold font-mono text-amber-400 mt-1">
                    {issueAccuracyPct}%
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-600">({issueMatchesCount} of {runCount} matched)</span>
                </div>

              </div>

              {/* TABULATED AUDIT COMPACT MATCHES */}
              <div className="bg-slate-950/60 border border-slate-850/80 rounded-xl overflow-hidden shadow-inner max-h-[300px] overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 font-mono font-semibold uppercase tracking-wider text-[9px] border-b border-slate-850/40">
                      <th className="px-4 py-2.5">Case index</th>
                      <th className="px-4 py-2.5">User ID</th>
                      <th className="px-4 py-2.5 text-center">Status Comparison</th>
                      <th className="px-4 py-2.5 text-center">Part Comparison</th>
                      <th className="px-4 py-2.5 text-center">Issue Comparison</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850/30 text-slate-400 font-mono">
                    {Object.entries(testedIndices).map(([idxStr, pred]) => {
                      const idx = parseInt(idxStr);
                      const groundTruth = sampleClaims[idx];
                      if (!groundTruth) return null;

                      const p = pred as ClaimOutput;
                      const statusMatch = p.claim_status === groundTruth.claim_status;
                      const partMatch = p.object_part === groundTruth.object_part;
                      const issueMatch = p.issue_type === groundTruth.issue_type;

                      return (
                        <tr key={idx} className="hover:bg-slate-900/40 text-[11px] leading-relaxed">
                          <td className="px-4 py-2 text-slate-500 font-bold">#{String(idx + 1).padStart(2, '0')}</td>
                          <td className="px-4 py-2 text-teal-400 font-bold">{groundTruth.user_id}</td>
                          <td className="px-4 py-2 text-center text-[10px]">
                            <span className={`inline-block px-1.5 py-0.5 rounded font-bold uppercase ${
                              statusMatch ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                            }`}>
                              {statusMatch ? 'MATCH' : `GT: ${groundTruth.claim_status}`}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-center text-[10px]">
                            <span className={`inline-block px-1.5 py-0.5 rounded font-bold uppercase ${
                              partMatch ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                            }`}>
                              {partMatch ? 'MATCH' : `GT: ${groundTruth.object_part}`}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-center text-[10px]">
                            <span className={`inline-block px-1.5 py-0.5 rounded font-bold uppercase ${
                              issueMatch ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                            }`}>
                              {issueMatch ? 'MATCH' : `GT: ${groundTruth.issue_type}`}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

            </div>
          ) : (
            <div className="text-center p-10 border border-dashed border-slate-800 rounded-xl bg-slate-950/20 text-slate-500 flex flex-col items-center gap-2 justify-center">
              <ShieldAlert className="w-8 h-8 text-slate-700 animate-pulse" />
              <div className="text-xs">
                <p className="font-semibold text-slate-400">Benchmark Audit Awaiting Refresh</p>
                <p className="mt-1 max-w-xs text-[11.5px] leading-relaxed">
                  Executing comparative checks will loop row-by-row through the sample ground-truth to analyze accuracy. This provides model verification confidence data.
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
