import React, { useState, useEffect } from 'react';
import { 
  Play, 
  CheckCircle, 
  AlertTriangle, 
  Image as ImageIcon, 
  TrendingUp, 
  FileText, 
  ShieldAlert, 
  HelpCircle,
  Eye,
  CheckCircle2,
  XCircle,
  AlertOctagon,
  Gauge
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ClaimInput, ClaimOutput } from '../types';

interface ClaimReviewerProps {
  claims: ClaimInput[];
  sampleClaims: ClaimOutput[];
  outputClaims: ClaimOutput[];
  userHistory: any[];
}

export default function ClaimReviewer({ 
  claims, 
  sampleClaims, 
  outputClaims,
  userHistory 
}: ClaimReviewerProps) {
  const [isSampleMode, setIsSampleMode] = useState<boolean>(true);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [customResult, setCustomResult] = useState<any | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const currentList = isSampleMode ? sampleClaims : claims;
  const currentItem = currentList[selectedIndex];

  // Lookup the output row if it exists for test claims
  const outputRow = !isSampleMode 
    ? outputClaims.find(o => o.user_id === currentItem?.user_id && o.user_claim === currentItem?.user_claim)
    : null;

  const userRecord = currentItem 
    ? userHistory.find(u => u.user_id === currentItem.user_id)
    : null;

  useEffect(() => {
    setSelectedIndex(0);
    setCustomResult(null);
    setErrorMessage(null);
  }, [isSampleMode]);

  useEffect(() => {
    setCustomResult(null);
    setErrorMessage(null);
  }, [selectedIndex]);

  const handleEvaluate = async () => {
    if (!currentItem) return;
    setIsEvaluating(true);
    setErrorMessage(null);
    setCustomResult(null);

    try {
      const response = await fetch('/api/evaluate_row', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          row_id: selectedIndex,
          is_sample: isSampleMode
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to analyze claim.');
      }
      setCustomResult(data.prediction);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Verification endpoint error. Please ensure GEMINI_API_KEY is configured.');
    } finally {
      setIsEvaluating(false);
    }
  };

  const statusColors: Record<string, string> = {
    supported: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    contradicted: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
    not_enough_information: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  };

  const severityColors: Record<string, string> = {
    high: 'bg-red-500/10 text-red-400 border-red-500/20',
    medium: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    low: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    none: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
    unknown: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full items-stretch" id="claims-workbench">
      {/* LEFT SIDE: Claims selector list */}
      <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col max-h-[750px] overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h2 className="font-sans font-medium text-slate-200">Claims Database</h2>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button 
              onClick={() => setIsSampleMode(true)}
              className={`px-3 py-1.5 rounded-md font-medium transition ${isSampleMode ? 'bg-slate-800 text-teal-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Samples
            </button>
            <button 
              onClick={() => setIsSampleMode(false)}
              className={`px-3 py-1.5 rounded-md font-medium transition ${!isSampleMode ? 'bg-slate-800 text-teal-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Test Inputs
            </button>
          </div>
        </div>

        <div className="flex bg-slate-950/50 p-2.5 border-b border-slate-800 text-xs text-slate-400 font-mono justify-between">
          <span>{isSampleMode ? 'Ground-Truth Labeled' : 'Pending Evaluation'}</span>
          <span>{currentList.length} cases</span>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 font-sans">
          {currentList.map((item, idx) => {
            const isSelected = idx === selectedIndex;
            const hasTestedOutput = !isSampleMode && outputClaims.some(o => o.user_id === item.user_id && o.user_claim === item.user_claim);
            return (
              <button
                key={idx}
                id={`claim-idx-${idx}`}
                onClick={() => setSelectedIndex(idx)}
                className={`w-full text-left p-3.5 transition flex flex-col gap-1.5 relative ${
                  isSelected ? 'bg-slate-800/40 border-l-2 border-teal-500' : 'hover:bg-slate-800/10'
                }`}
              >
                <div className="flex justify-between items-start w-full">
                  <span className="font-mono text-xs text-teal-400">{item.user_id}</span>
                  <div className="flex gap-1 items-center">
                    <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                      {item.claim_object}
                    </span>
                    {isSampleMode ? (
                      <span className={`text-[9px] font-semibold px-1 rounded-sm uppercase ${
                        (item as ClaimOutput).claim_status === 'supported' ? 'bg-emerald-500/20 text-emerald-400' :
                        (item as ClaimOutput).claim_status === 'contradicted' ? 'bg-rose-500/20 text-rose-400' :
                        'bg-amber-500/20 text-amber-400'
                      }`}>
                        {(item as ClaimOutput).claim_status}
                      </span>
                    ) : (
                      hasTestedOutput && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Processed in output batch" />
                      )
                    )}
                  </div>
                </div>

                <p className="text-slate-300 text-xs line-clamp-2 italic font-serif leading-relaxed">
                  {item.user_claim.split('|')[0].replace('Customer:', '').trim()}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
                  <span className="flex items-center gap-1 font-mono">
                    <ImageIcon className="w-3 h-3 text-slate-500" />
                    {item.image_paths.split(';').length} images
                  </span>
                  <span className="font-mono text-slate-600">Case #{String(idx + 1).padStart(3, '0')}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* RIGHT SIDE: Claim Details and Verification Console */}
      <div className="lg:col-span-8 flex flex-col gap-6 max-h-[750px] overflow-y-auto pr-1 font-sans">
        {currentItem ? (
          <>
            {/* Context Card */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col gap-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm bg-slate-950 border border-slate-800 text-teal-400 px-2.5 py-1 rounded">
                    {currentItem.user_id}
                  </span>
                  <span className="text-sm text-slate-400">/</span>
                  <span className="text-xs font-mono uppercase bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded text-slate-300">
                    {currentItem.claim_object}
                  </span>
                </div>

                <button
                  onClick={handleEvaluate}
                  disabled={isEvaluating}
                  id="btn-evaluate-claim"
                  className={`flex items-center gap-2 px-4 py-2 font-medium text-xs rounded-lg transition-all ${
                    isEvaluating 
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-slate-950 shadow-md shadow-emerald-500/5 hover:-translate-y-0.5 active:translate-y-0'
                  }`}
                >
                  <Play className={`w-3.5 h-3.5 fill-current ${isEvaluating ? 'animate-pulse' : ''}`} />
                  {isEvaluating ? 'Evaluating with Gemini...' : 'Verify Claim with Gemini'}
                </button>
              </div>

              {/* Chat Conversation Transcript */}
              <div>
                <h3 className="text-slate-400 font-mono text-[10px] uppercase tracking-wider mb-2">Claim Conversation Transcript</h3>
                <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3.5 max-h-[140px] overflow-y-auto flex flex-col gap-2.5">
                  {currentItem.user_claim.split('|').map((bubble, bIdx) => {
                    const isUser = bubble.trim().toLowerCase().startsWith('customer:');
                    const text = bubble.replace(/^(customer|support|agent|reviewer):/i, '').trim();
                    return (
                      <div key={bIdx} className={`flex flex-col max-w-[85%] ${isUser ? 'self-start' : 'self-end items-end'}`}>
                        <span className="text-[9px] font-mono text-slate-500 capitalize px-1">
                          {isUser ? 'Customer' : 'Claims Agent'}
                        </span>
                        <div className={`mt-0.5 px-3 py-2 rounded-lg text-xs leading-relaxed ${
                          isUser ? 'bg-slate-900 border border-slate-800 text-slate-200' : 'bg-slate-850 text-teal-300 border border-teal-900/30'
                        }`}>
                          {text}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submitted Images Gallery */}
              <div>
                <h3 className="text-slate-400 font-mono text-[10px] uppercase tracking-wider mb-2">Attached Visual Evidence</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {currentItem.image_paths.split(';').map((imgUrl, iIdx) => {
                    // Normalize image display using server-hosted mount path
                    const srcUrl = imgUrl.startsWith('images/') ? `/${imgUrl}` : imgUrl;
                    return (
                      <div key={iIdx} className="relative group bg-slate-950 border border-slate-800 rounded-lg overflow-hidden h-[110px] flex items-center justify-center">
                        <img 
                          src={srcUrl} 
                          alt="Claim evidence" 
                          referrerPolicy="no-referrer"
                          className="max-h-full max-w-full object-contain transition duration-300 group-hover:scale-105"
                        />
                        <div className="absolute bottom-1 right-1 bg-slate-950/80 border border-slate-800/80 rounded px-1.5 py-0.5 font-mono text-[9px] text-slate-400">
                          img_{iIdx + 1}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* User History Risk Alert */}
              {userRecord && (
                <div className={`border p-3 rounded-lg flex gap-3 items-center ${
                  userRecord.history_flags !== 'none'
                    ? 'bg-rose-500/5 border-rose-500/20 text-rose-300'
                    : 'bg-slate-950 border-slate-800/80 text-slate-400'
                }`}>
                  <ShieldAlert className={`w-5 h-5 flex-shrink-0 ${userRecord.history_flags !== 'none' ? 'text-rose-400' : 'text-slate-500'}`} />
                  <div className="text-xs">
                    <p className="font-mono text-[10px] uppercase tracking-wider text-slate-500">Customer Risk Profile</p>
                    <p className="mt-0.5 font-medium">
                      {userRecord.history_summary} 
                      {userRecord.history_flags !== 'none' && ` (${userRecord.history_flags.split(';').join(', ')})`}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* ERROR ALERT */}
            {errorMessage && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-4 rounded-xl flex items-start gap-3">
                <AlertOctagon className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div className="text-xs">
                  <h4 className="font-semibold">Analysis Failed</h4>
                  <p className="mt-1 leading-relaxed">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* RESULTS SCREEN */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Box 1: Ground-Truth/Saved Results */}
              {isSampleMode ? (
                <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl shadow-slate-950/40">
                  <div className="bg-slate-950/80 px-4.5 py-2.5 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-xs text-indigo-400 flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5" /> Expected Ground-Truth Result
                    </span>
                  </div>
                  <div className="p-4.5 flex flex-col gap-3 text-xs text-slate-300">
                    <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block">CLAIM STATUS</span>
                        <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${statusColors[(currentItem as ClaimOutput).claim_status] || 'bg-slate-800 text-slate-100 border-slate-700'}`}>
                          {(currentItem as ClaimOutput).claim_status}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block">SEVERITY LEVEL</span>
                        <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${severityColors[(currentItem as ClaimOutput).severity] || 'bg-slate-800 text-slate-100 border-slate-700'}`}>
                          {(currentItem as ClaimOutput).severity}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block">COMPONENTS</span>
                        <span className="text-xs block mt-1 font-medium text-slate-200 capitalise">
                          {(currentItem as ClaimOutput).object_part?.replace(/_/g, ' ')}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block">ISSUE FAMILY</span>
                        <span className="text-xs block mt-1 font-medium text-slate-200 capitalise">
                          {(currentItem as ClaimOutput).issue_type?.replace(/_/g, ' ')}
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">IMAGE SUFFICENCY CHECK ({(currentItem as ClaimOutput).valid_image ? 'VALID' : 'INVALID'})</span>
                      <p className="leading-relaxed text-slate-300 italic">
                        &ldquo;{(currentItem as ClaimOutput).evidence_standard_met_reason}&rdquo;
                      </p>
                    </div>

                    <div>
                      <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">IMAGE-GROUNDED JUSTIFICATION</span>
                      <p className="leading-relaxed text-slate-200">
                        {(currentItem as ClaimOutput).claim_status_justification}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/60 font-mono text-[10px]">
                      <div>
                        <span className="text-slate-500">RISK FLAGS</span>
                        <p className="text-slate-400 font-semibold uppercase tracking-wider">
                          {(currentItem as ClaimOutput).risk_flags}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">SUPPORTING IMAGES</span>
                        <p className="text-emerald-400 font-semibold font-mono">
                          {(currentItem as ClaimOutput).supporting_image_ids}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                  <div className="bg-slate-950/80 px-4.5 py-2.5 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-xs text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" /> Output CSV Prediction Status
                    </span>
                  </div>
                  {outputRow ? (
                    <div className="p-4.5 flex flex-col gap-3 text-xs text-slate-300">
                      <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">PREDICTED STATUS</span>
                          <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${statusColors[outputRow.claim_status] || 'bg-slate-800'}`}>
                            {outputRow.claim_status}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">PREDICTED SEVERITY</span>
                          <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${severityColors[outputRow.severity] || 'bg-slate-800'}`}>
                            {outputRow.severity}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">OBJECT COMPONENT</span>
                          <span className="text-xs mt-1 block font-medium capitalize text-slate-200">
                            {outputRow.object_part?.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">DETECTED ISSUE</span>
                          <span className="text-xs mt-1 block font-medium capitalize text-slate-200">
                            {outputRow.issue_type?.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">EVIDENCE EVALUATION</span>
                        <p className="leading-relaxed italic text-slate-300">
                          &ldquo;{outputRow.evidence_standard_met_reason}&rdquo;
                        </p>
                      </div>

                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">REASONING JUSTIFICATION</span>
                        <p className="leading-relaxed text-slate-200">
                          {outputRow.claim_status_justification}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/60 font-mono text-[10px]">
                        <div>
                          <span className="text-slate-500">RISK FLAGS</span>
                          <p className="text-slate-400 font-semibold uppercase tracking-wider">{outputRow.risk_flags}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">SUPPORTING IMAGES</span>
                          <p className="text-teal-400 font-semibold font-mono">{outputRow.supporting_image_ids}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-10 flex flex-col items-center justify-center text-center gap-3">
                      <HelpCircle className="w-8 h-8 text-slate-600 animate-pulse" />
                      <div className="text-xs text-slate-500">
                        <p className="font-semibold">No Output Row Found</p>
                        <p className="mt-1 max-w-[200px]">Run batch processing to populate data or verify individual claims below.</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Box 2: LIVE API RUN */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden relative shadow-xl shadow-slate-950/40">
                <div className="bg-slate-950/80 px-4.5 py-2.5 border-b border-indigo-950/60 flex items-center justify-between">
                  <span className="font-mono text-xs text-teal-400 flex items-center gap-1.5">
                    <Gauge className="w-3.5 h-3.5" /> Multimodal Review Console (Live Gemini)
                  </span>
                  {isEvaluating && (
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
                    </span>
                  )}
                </div>

                <AnimatePresence mode="wait">
                  {isEvaluating ? (
                    <motion.div 
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="p-10 flex flex-col items-center justify-center text-center gap-4 min-h-[300px]"
                    >
                      <div className="w-10 h-10 border-2 border-teal-500/10 border-t-teal-500 rounded-full animate-spin" />
                      <div className="text-xs text-slate-400">
                        <p className="font-semibold font-mono text-teal-400">LOADING IMAGES & LAUNCHING AGENT</p>
                        <p className="mt-1 text-[10px] text-slate-500 italic max-w-xs">Connecting to Gemini-3.5-Flash to run multimodal verification rules...</p>
                      </div>
                    </motion.div>
                  ) : customResult ? (
                    <motion.div
                      key="result"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      className="p-4.5 flex flex-col gap-3 text-xs text-slate-300"
                    >
                      <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">LIVE STATUS DECISION</span>
                          <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${statusColors[customResult.claim_status] || 'bg-slate-800'}`}>
                            {customResult.claim_status}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">SEVERITY</span>
                          <span className={`inline-block border px-2 py-0.5 rounded-md font-semibold mt-1 capitalize text-[10px] ${severityColors[customResult.severity] || 'bg-slate-800'}`}>
                            {customResult.severity}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pb-2 border-b border-slate-800/60 font-mono">
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">LOCALIZED PART</span>
                          <span className="text-xs mt-1 block font-medium capitalize text-slate-200">
                            {customResult.object_part?.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 uppercase text-[9px] block">ISSUE INFERRED</span>
                          <span className="text-xs mt-1 block font-medium capitalize text-slate-200">
                            {customResult.issue_type?.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">VERDICT ARGUMENT</span>
                        <p className="leading-relaxed text-slate-200">
                          {customResult.claim_status_justification}
                        </p>
                      </div>

                      <div>
                        <span className="text-slate-500 uppercase text-[9px] block mb-1 font-mono">EVIDENCE VALIDITY REASON</span>
                        <p className="leading-relaxed italic text-slate-300">
                          &ldquo;{customResult.evidence_standard_met_reason}&rdquo;
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/60 font-mono text-[10px]">
                        <div>
                          <span className="text-slate-500">RISK FLAGS DETECTED</span>
                          <span className="text-rose-400 font-semibold block uppercase tracking-wider">{customResult.risk_flags}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">SUPPORTED IMAGES</span>
                          <span className="text-teal-400 font-semibold block uppercase tracking-wider">{customResult.supporting_image_ids}</span>
                        </div>
                      </div>

                      {isSampleMode && (
                        <div className="mt-2.5 p-2 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center text-[10px] font-mono">
                          <span className="text-slate-500">ACCURACY CHECK:</span>
                          <span className={customResult.claim_status === (currentItem as ClaimOutput).claim_status ? 'text-emerald-400 flex items-center gap-1 font-bold' : 'text-rose-400 flex items-center gap-1 font-bold'}>
                            {customResult.claim_status === (currentItem as ClaimOutput).claim_status ? (
                              <><CheckCircle2 className="w-3.5 h-3.5" /> MATCHED STANDARD</>
                            ) : (
                              <><XCircle className="w-3.5 h-3.5" /> STATUS MISMATCH</>
                            )}
                          </span>
                        </div>
                      )}
                    </motion.div>
                  ) : (
                    <div className="p-10 flex flex-col items-center justify-center text-center gap-3 min-h-[300px]" key="empty">
                      <ImageIcon className="w-8 h-8 text-slate-600" />
                      <div className="text-xs text-slate-500">
                        <p className="font-semibold text-slate-400">Awaiting Real-Time Trigger</p>
                        <p className="mt-1 max-w-[220px]">Click the verification button above to execute a fresh live multimodal evaluation.</p>
                      </div>
                    </div>
                  )}
                </AnimatePresence>
              </div>

            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center text-center p-20 bg-slate-900 rounded-xl border border-slate-800">
            <ImageIcon className="w-12 h-12 text-slate-700 animate-pulse" />
            <h3 className="font-sans font-semibold text-slate-300 mt-4">No Claims Selected</h3>
            <p className="text-slate-500 text-xs mt-1">Please select an active claim on the left to begin verifying.</p>
          </div>
        )}
      </div>
    </div>
  );
}
