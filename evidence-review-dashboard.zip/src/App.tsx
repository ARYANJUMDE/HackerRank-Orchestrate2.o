import React, { useState, useEffect, useCallback } from 'react';
import { 
  PlayCircle, 
  Settings, 
  HelpCircle, 
  BookOpen, 
  User, 
  ShieldCheck, 
  ChevronRight,
  Sparkles,
  ClipboardList,
  Cpu,
  Layers,
  Activity,
  Gauge
} from 'lucide-react';
import ClaimReviewer from './components/ClaimReviewer';
import BatchPipeline from './components/BatchPipeline';
import AnalyticsCharts from './components/AnalyticsCharts';
import KnowledgeBase from './components/KnowledgeBase';
import { ClaimInput, ClaimOutput, UserHistory, EvidenceRequirement } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'reviewer' | 'pipeline' | 'analytics' | 'knowledge'>('reviewer');
  const [claims, setClaims] = useState<ClaimInput[]>([]);
  const [sampleClaims, setSampleClaims] = useState<ClaimOutput[]>([]);
  const [outputClaims, setOutputClaims] = useState<ClaimOutput[]>([]);
  const [userHistory, setUserHistory] = useState<UserHistory[]>([]);
  const [evidenceRequirements, setEvidenceRequirements] = useState<EvidenceRequirement[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchAppData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [claimsRes, sampleRes, outputRes, historyRes, reqRes] = await Promise.all([
        fetch('/api/claims'),
        fetch('/api/sample_claims'),
        fetch('/api/output'),
        fetch('/api/user_history'),
        fetch('/api/evidence_requirements')
      ]);

      if (claimsRes.ok) setClaims(await claimsRes.json());
      if (sampleRes.ok) setSampleClaims(await sampleRes.json());
      if (outputRes.ok) setOutputClaims(await outputRes.json());
      if (historyRes.ok) setUserHistory(await historyRes.json());
      if (reqRes.ok) setEvidenceRequirements(await reqRes.json());
    } catch (err) {
      console.error('Error fetching dashboard states:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshOutputs = useCallback(async () => {
    try {
      const res = await fetch('/api/output');
      if (res.ok) {
        setOutputClaims(await res.json());
      }
    } catch (err) {
      console.error('Error refreshing output database:', err);
    }
  }, []);

  useEffect(() => {
    fetchAppData();
  }, [fetchAppData]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* GLOBAL BANNER HEADER */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-teal-500 to-indigo-600 rounded-lg text-slate-950 shadow-md shadow-emerald-500/10">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-sans font-semibold text-sm tracking-tight text-slate-100 uppercase">
                Multi-Modal Claims verifier
              </h1>
              <span className="text-[10px] font-mono bg-teal-500/10 text-teal-400 px-1.5 py-0.5 rounded border border-teal-500/15 font-bold uppercase tracking-wider">
                Active core
              </span>
            </div>
            <p className="text-[10px] font-mono text-slate-500 mt-0.5">
              Automated claims inspection & evidence compliance dashboard powered by Gemini
            </p>
          </div>
        </div>

        {/* Global stats bar */}
        <div className="hidden md:flex items-center gap-6 font-mono text-xs">
          <div className="text-right">
            <span className="text-slate-500 block text-[9px] uppercase font-bold text-slate-600">Claims loaded</span>
            <span className="text-slate-300 font-bold">{claims.length} pending</span>
          </div>
          <div className="border-r border-slate-900 h-6" />
          <div className="text-right">
            <span className="text-slate-500 block text-[9px] uppercase font-bold text-slate-600">Sample baselines</span>
            <span className="text-slate-300 font-bold">{sampleClaims.length} labeled</span>
          </div>
          <div className="border-r border-slate-900 h-6" />
          <div className="text-right">
            <span className="text-slate-500 block text-[9px] uppercase font-bold text-slate-600">Outputs generated</span>
            <span className="text-teal-400 font-bold">{outputClaims.length} verified</span>
          </div>
        </div>
      </header>

      {/* CORE WORKSPACE GRID */}
      <div className="flex-1 flex flex-col md:flex-row items-stretch">
        
        {/* Workspace Sidebar Tabs links */}
        <nav className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-900 bg-slate-950/40 p-4.5 flex flex-col gap-1 flex-shrink-0 font-sans">
          <span className="text-[9px] font-mono text-slate-500 block uppercase tracking-wider pl-2.5 mb-2.5">
            Operational Tabs
          </span>

          {[
            { id: 'reviewer', label: 'Evaluation Bench', icon: Gauge, desc: 'Single row verifier' },
            { id: 'pipeline', label: 'Batch pipeline', icon: Layers, desc: 'Generate output.csv' },
            { id: 'analytics', label: 'System Analytics', icon: Activity, desc: 'Detections & benchmarks' },
            { id: 'knowledge', label: 'Regulations Hub', icon: BookOpen, desc: 'Requirements & user logs' },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full text-left p-3 rounded-lg text-xs transition flex items-center justify-between group ${
                  isActive 
                    ? 'bg-gradient-to-r from-teal-500/10 to-indigo-500/10 text-teal-400 border border-teal-500/20'
                    : 'text-slate-400 hover:bg-slate-850/20 hover:text-slate-200 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-teal-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
                  <div>
                    <span className="font-semibold block">{tab.label}</span>
                    <span className="text-[9px] font-mono opacity-50 block mt-0.5">{tab.desc}</span>
                  </div>
                </div>
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-teal-500" />}
              </button>
            );
          })}

          <div className="mt-auto border-t border-slate-900/60 pt-4 text-[10px] font-mono text-slate-600 leading-normal pl-2.5 hidden md:block">
            <p>HackerRank Orchestrate</p>
            <p>AI Studio Build © 2026</p>
          </div>
        </nav>

        {/* PRIMARY ACTIVE TAB DISPLAY SCREEN */}
        <main className="flex-1 bg-slate-950/10 p-6 overflow-hidden flex flex-col min-h-[500px]">
          {isLoading && claims.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center gap-4">
              <div className="w-10 h-10 border-2 border-teal-500/10 border-t-teal-500 rounded-full animate-spin" />
              <div className="text-xs text-slate-500 font-mono">LOADING WORKSPACE DATABASE REGISTERS...</div>
            </div>
          ) : (
            <div className="flex-1 min-h-0">
              {activeTab === 'reviewer' && (
                <ClaimReviewer 
                  claims={claims} 
                  sampleClaims={sampleClaims} 
                  outputClaims={outputClaims}
                  userHistory={userHistory}
                />
              )}
              {activeTab === 'pipeline' && (
                <BatchPipeline 
                  outputClaims={outputClaims}
                  refreshOutputs={refreshOutputs}
                />
              )}
              {activeTab === 'analytics' && (
                <AnalyticsCharts 
                  sampleClaims={sampleClaims} 
                  outputClaims={outputClaims}
                />
              )}
              {activeTab === 'knowledge' && (
                <KnowledgeBase 
                  userHistory={userHistory} 
                  evidenceRequirements={evidenceRequirements}
                />
              )}
            </div>
          )}
        </main>

      </div>
    </div>
  );
}
