import fs from 'fs';
import path from 'path';

const REPO_OWNER = 'interviewstreet';
const REPO_NAME = 'hackerrank-orchestrate-june26';
const BASE_URL = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents`;

async function fetchJson(url: string) {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch ${url}: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

async function fetchRaw(url: string): Promise<Buffer> {
  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
  });
  if (!res.ok) {
    throw new Error(`Failed to fetch raw ${url}: ${res.status} ${res.statusText}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

interface GithubContent {
  name: string;
  path: string;
  sha: string;
  size: number;
  url: string;
  html_url: string;
  git_url: string;
  download_url: string | null;
  type: 'file' | 'dir';
}

async function downloadDir(dirPath: string, localDir: string) {
  console.log(`Downloading directory: ${dirPath} -> ${localDir}`);
  fs.mkdirSync(localDir, { recursive: true });
  
  const contents = await fetchJson(`${BASE_URL}/${dirPath}`) as GithubContent[];
  for (const item of contents) {
    const localPath = path.join(localDir, item.name);
    if (item.type === 'dir') {
      if (item.name === 'images') {
        console.log(`Skipping images directory to save bandwidth`);
        continue;
      }
      await downloadDir(item.path, localPath);
    } else if (item.type === 'file' && item.download_url) {
      if (fs.existsSync(localPath)) {
        console.log(`File already exists, skipping: ${item.path}`);
        continue;
      }
      console.log(`Downloading file: ${item.path} -> ${localPath}`);
      const buffer = await fetchRaw(item.download_url);
      fs.writeFileSync(localPath, buffer);
    }
  }
}

async function main() {
  try {
    const targetDir = path.join(process.cwd(), 'imported_repo');
    await downloadDir('', targetDir);
    console.log('Download complete!');
  } catch (err) {
    console.error('Error downloading repo:', err);
  }
}

main();
